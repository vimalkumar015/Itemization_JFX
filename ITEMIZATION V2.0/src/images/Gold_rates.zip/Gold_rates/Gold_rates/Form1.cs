﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Collections;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string temp;
        Dictionary<string,string> myDictionary=new Dictionary<string,string>();
        
        public Form1()
        {
            InitializeComponent();
        }

        // CLOSE APPLICATION
        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            myDictionary = null;
            this.Dispose();
        }       
      
        public string rates(string urlAddress)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(urlAddress);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream receiveStream = response.GetResponseStream();
                    StreamReader readStream = null;
                    if (response.CharacterSet == null)
                        readStream = new StreamReader(receiveStream);
                    else
                        readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));
                    string data = readStream.ReadToEnd();
                    response.Close();
                    readStream.Close();
                    
                    temp = data.Substring(data.LastIndexOf("10g"), 30);
                    temp = temp.Replace("<TD>", "");
                    temp = temp.Replace("</TD>", "");
                    temp = temp.Replace("\t", " ");
                    temp = temp.Replace("\n", " ");
                }
            }
            catch (Exception) { MessageBox.Show("Cannot connect to the server."); }
            return temp;
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            
            // SHOWING FORM AT THE RIGHT UPPER CORNER
            this.Left = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Right - this.Width;
            this.Top = 0;            
             //CHECK IF SYSTEM HAS INTERNET CONNECTION
            if (!HasConnection())
            {
                label4.Text = "No Internet connection!";
                comboBox1.Enabled = false;
                return;
            }
            
        }

        
        public static bool HasConnection()
        {
            // CHECK IF SYSTEM HAS INTERNET CONNECTION
            try
            {
                System.Net.IPHostEntry i = System.Net.Dns.GetHostEntry("www.indiagoldrate.com");
                return true;
            }
            catch
            {
                return false;
            }
        }

        //SHOW RATES OF SELECTED CITY
        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lbl_gold.Text = "Gold: ";
            lbl_silver.Text = "Silver: ";
            string temp = comboBox1.SelectedValue.ToString();
            temp = temp.Substring(0, temp.IndexOf("@"));            
            lbl_gold.Text += rates(temp);
            temp = comboBox1.SelectedValue.ToString();
            temp = temp.Substring(temp.IndexOf("@") + 1);
            lbl_silver.Text += rates(temp);
        }
    }
}
